package com.bsli.batch.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bsli.batch.dao.CityDAO;
import com.bsli.batch.model.City;

@RestController
@RequestMapping("/demo")
public class ServiceController 
{

	@Autowired
	private CityDAO cityDAO;
	
	@RequestMapping("/getCityList")
	public List<City> listCities()
	{
		System.out.println("ServiceController.listCities()");
		List<City> list = new ArrayList<City>();
		list = cityDAO.fetchAllCities();
		
		return list;
	}
}
