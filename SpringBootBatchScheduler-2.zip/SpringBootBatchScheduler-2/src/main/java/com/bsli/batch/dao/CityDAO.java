package com.bsli.batch.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bsli.batch.model.City;

@Repository
public class CityDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final String SQL = "SELECT * FROM CITY WHERE district='Maharashtra'";
	
	public List<City> fetchAllCities()
	{
		List<City> cities = new ArrayList<>();
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(SQL);
		
		for (Map<String, Object> row : rows) {
			City city = new City();
			city.setId((int)row.get("id"));
			city.setName((String)row.get("Name"));
			city.setCountryCode((String)row.get("CountryCode"));
				
			cities.add(city);
		}
		return cities;
	}
}
