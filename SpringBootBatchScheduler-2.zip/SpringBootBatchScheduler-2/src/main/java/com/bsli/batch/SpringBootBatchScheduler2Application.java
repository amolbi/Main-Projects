package com.bsli.batch;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.bsli.batch.dao.CityDAO;
import com.bsli.batch.model.City;

@SpringBootApplication
@EnableScheduling
public class SpringBootBatchScheduler2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBatchScheduler2Application.class, args);
	}
	
	@Autowired
	private CityDAO cityDAO;
	
	@Scheduled(fixedDelay = 30000)
	public void run() 
	{
		System.out.println("Current time is :: " + Calendar.getInstance().getTime());
		
		List<City> list = new ArrayList<City>();
		list = cityDAO.fetchAllCities();
		
		System.out.println(list);
	}

}
