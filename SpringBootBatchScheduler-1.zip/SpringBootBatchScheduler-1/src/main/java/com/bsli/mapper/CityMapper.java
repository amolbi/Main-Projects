package com.bsli.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bsli.model.City;

public class CityMapper implements RowMapper<City>{

	@Override
	public City mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new City(rs.getLong("id"), rs.getString("name"), rs.getInt("population"));
	}

}
