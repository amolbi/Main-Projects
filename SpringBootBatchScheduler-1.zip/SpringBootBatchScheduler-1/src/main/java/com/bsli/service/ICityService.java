package com.bsli.service;

import java.util.List;

import com.bsli.model.City;

public interface ICityService {
	List<City> findAll();
    City findById(Long id);
}
