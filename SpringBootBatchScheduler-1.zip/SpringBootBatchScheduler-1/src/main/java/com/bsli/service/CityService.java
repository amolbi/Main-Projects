package com.bsli.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.bsli.model.City;
import com.bsli.repository.CityRepository;

@Repository
@Service
public class CityService //implements ICityService
{
	
	@Autowired
	private CityRepository cityRepository;
	
	public List<City> findAll()
	{
		List<City> cities = cityRepository.findAll();
		return cities;
	}
	
	/*
	 * @Autowired private JdbcTemplate jdbcTemplate;
	 * 
	 * @Override public List<City> findAll() { String sql =
	 * "SELECT * FROM CITY WHERE district='Maharashtra'";
	 * 
	 * return jdbcTemplate.query(sql, new CityMapper()); }
	 * 
	 * @Override public City findById(Long id) { String sql =
	 * "SELECT * FROM CITY WHERE id = ?";
	 * 
	 * return jdbcTemplate.queryForObject(sql, new Object[]{id}, new CityMapper());
	 * }
	 */

}
