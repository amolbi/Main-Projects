package com.bsli.batch;

import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.bsli.model.City;
import com.bsli.service.CityService;

//@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@EnableScheduling
public class SpringBootBatchScheduler1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBatchScheduler1Application.class, args);
	}
	
//	@Autowired
//    private CityService cityService;
	

	@Scheduled(fixedDelay = 60000)
	public void run() 
	{
		System.out.println("Current time is :: " + Calendar.getInstance().getTime());
		
//        List<City> data = cityService.findAll();
//        System.out.println(data);
	}
}
