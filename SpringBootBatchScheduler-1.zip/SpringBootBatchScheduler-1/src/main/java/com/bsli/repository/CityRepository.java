package com.bsli.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bsli.model.City;

public interface CityRepository extends JpaRepository<City, Integer>{
	
	
	  @Query("SELECT * FROM CITY WHERE district='Maharashtra'") public
	  List<City> getAllCities();
	 
	
}
