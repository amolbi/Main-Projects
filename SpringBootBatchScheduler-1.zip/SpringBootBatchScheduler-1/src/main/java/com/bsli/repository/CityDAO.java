package com.bsli.repository;

import java.util.Collection;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class CityDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public Collection<Map<String, Object>> getAllCities()
	{
		Collection<Map<String, Object>> rows = jdbcTemplate.queryForList("SELECT * FROM CITY WHERE district='Maharashtra'");

		return rows;
	}
}
