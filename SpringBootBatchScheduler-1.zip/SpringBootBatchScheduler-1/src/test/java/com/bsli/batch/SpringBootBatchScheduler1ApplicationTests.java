package com.bsli.batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBatchScheduler1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
