package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "V_LOOKUP_VALUES" , schema = "UI")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DashboardFilter {

	@Id
	@JsonProperty("description")
	private String description;
	@JsonProperty("code")
	private String code;
	@JsonProperty("category")
	private String category;
}

