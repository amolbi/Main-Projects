package com.bsli.dashboard.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsli.dashboard.exception.UserDefinedException;
import com.bsli.dashboard.model.DashBoardRequest;
import com.bsli.dashboard.model.TatReportEntity;
import com.bsli.dashboard.model.TatReportResponse;
import com.bsli.dashboard.repository.TatReportRepository;

@Service
public class TatReportService {

	@Autowired
	private TatReportRepository reportRepository;

	public TatReportResponse getTatReport(DashBoardRequest cardRequest) {

		List<TatReportEntity> findAll = reportRepository.findAll();

		if (Optional.ofNullable(findAll).isPresent()) {
			TatReportResponse tatReportResponse = new TatReportResponse();
			tatReportResponse.setTatReport(findAll);
			return tatReportResponse;
		} else {
			throw new UserDefinedException(105,"TAT Reports details are not available");
		}
	}
}