package com.bsli.dashboard.model;

import java.io.InputStream;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IQCCMDownloadResponse {
	
	private String contentType;
	private String extension;
	private InputStream inputStream;
	private byte[] fileByteArray;
	private String status;
	private int size;

}
