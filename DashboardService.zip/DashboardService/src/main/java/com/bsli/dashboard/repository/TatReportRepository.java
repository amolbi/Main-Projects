package com.bsli.dashboard.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bsli.dashboard.model.TatReportEntity;

public interface TatReportRepository extends JpaRepository<TatReportEntity, Integer>{
}
