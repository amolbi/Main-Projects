package com.bsli.dashboard.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsli.dashboard.exception.UserDefinedException;
import com.bsli.dashboard.model.DashBoardRequest;
import com.bsli.dashboard.model.PolicyIssueTimeEntity;
import com.bsli.dashboard.model.PolicyIssueTimeResponse;
import com.bsli.dashboard.repository.PolicyIssuanceTimeRepository;

@Service
public class PolicyIssuanceTimeService {

	@Autowired
	private PolicyIssuanceTimeRepository issuanceTimeRepository;

	public PolicyIssueTimeResponse getPolicyIssuanceTime(DashBoardRequest cardRequest) {

		List<PolicyIssueTimeEntity> findAll = issuanceTimeRepository.findAll();

		if (Optional.ofNullable(findAll).isPresent()) {
			PolicyIssueTimeResponse issueTimeResponse = new PolicyIssueTimeResponse();
			issueTimeResponse.setPolicyIssueTime(findAll);
			return issueTimeResponse;
		} else {
			throw new UserDefinedException(102,"Policy issuance time is not available");
		}
	}
}
