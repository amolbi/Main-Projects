package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "V_UI_IQC_PROPOSER_DETAILS" , schema = "UI")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IQCCaseProposerDetailsEntity {

	@Id
	private String caseId;
	private String clientidPolicyowner;
	private String propAddress1;
	private String propAddress2;
	private String propAddress3;
	private String propArea;
	private String propCity;
	private String propEmail;
	private String propPin;
	private String propState;
	private String propAnnualincome;
	private String propDob;
	private String propFirstname;
	private String propGender;
	private String propLname;
	private String propMname;
	private String propMaritalstatus;
	private String propMobileno;
	private String propNationality;
	private String propOccupation;
	private String propPan;
	private String propTitle;
	private String customenameOwner;
	private String ageOwner;
	private String genderOwner;
	private String existingPolicyNo;
	private String previouspolicyno;
	private String annualIncome;
	private String parentSpouseIncome;
	private String relationshipWithLi;
	private String posidexDecision;
//	private String form60Ind;


	//@JsonProperty("Remarks")
	//private String remarks;
}
