package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "V_UI_CASE_TRACKER_AUDIT_DETAILS" , schema = "UI")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CaseAuditLogsEntity {

	@Id
	private int id;
	@JsonProperty("Case Id")
	private int caseId;
	@JsonProperty("Case Status")
	private String caseStatus;
	@JsonProperty("Remarks")
	private String remarks;
	@JsonProperty("Date Time")
	private String dateTime;
	@JsonProperty("Action By")
	private String actionBy;
	@JsonProperty("Pool")
	private String pool;
	@JsonProperty("Retry")
	private String isButton;
	@JsonProperty("param")
	private String param;

}
