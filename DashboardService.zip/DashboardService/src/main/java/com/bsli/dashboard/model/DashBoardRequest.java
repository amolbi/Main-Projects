package com.bsli.dashboard.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DashBoardRequest {

	private String searchCriteria;
	private String searchValue;
	private String fromDate;
	private String toDate;

	public boolean isValid() {
		return null != this.searchCriteria && null != this.searchValue;
	}
	
	public boolean isEmpty() {
		return !"".equalsIgnoreCase(searchCriteria) && !"".equalsIgnoreCase(searchValue);
	}
}
