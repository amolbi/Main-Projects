package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "V_UI_LIST_IQC_STP_KITTY_ALL" , schema = "UI")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ListIQCSTPKittyEntity {

	@Id
	@JsonProperty("Case Id")
	private String caseId;
	@JsonProperty("Application Number")
	private String appNo;
	@JsonProperty("Client Id")
	private String clientId;
	@JsonProperty("Policy Number")
	private String policyNo;
	@JsonProperty("Application Create Date")
	private String appCreateDt;
	@JsonProperty("Case Status")
	private String caseStatus;
	@JsonProperty("Remarks")
	private String remarks;
}
