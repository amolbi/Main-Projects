package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "V_UI_LIST_COUNT_SERVICE_FAILURES" , schema = "UI")
public class ServiceFailureEntity {

	@Id
	private int id;
	@JsonProperty("Activity")
	private String activity;
	@JsonProperty("Failure")
	private int failureNo;
	@JsonProperty("Percentage")
	private String percentage;
}
