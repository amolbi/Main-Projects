package com.bsli.dashboard.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bsli.dashboard.model.IQCCaseInsuredDetailsEntity;

public interface IQCCaseInsuredDetailsRepository extends JpaRepository<IQCCaseInsuredDetailsEntity, Integer> {

	@Query(value="SELECT * FROM UI.V_UI_IQC_INSURED_DETAILS p WHERE case_Id = :caseId",nativeQuery=true)
	public List<IQCCaseInsuredDetailsEntity> findByCaseIdCustom(@Param("caseId") int caseId);

}