package com.bsli.dashboard.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bsli.dashboard.model.IQCCasePlanDetailsEntity;

public interface IQCCasePlanDetailsRepository extends JpaRepository<IQCCasePlanDetailsEntity, Integer> {

	@Query(value="SELECT * FROM UI.V_UI_IQC_PLAN_DETAILS p WHERE case_Id = :caseId",nativeQuery=true)
	public List<IQCCasePlanDetailsEntity> findByCaseIdCustom(@Param("caseId") int caseId);

}