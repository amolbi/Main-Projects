package com.bsli.dashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bsli.dashboard.model.CaseTrackerDetailsEntity;
import com.bsli.dashboard.model.DashboardFilter;

public interface CaseTrackerRepository extends JpaRepository<CaseTrackerDetailsEntity, String>
{
	@Query(value="SELECT * FROM UI.V_UI_CASE_TRACKER_DETAILS p WHERE case_Id = :caseId",nativeQuery=true)
	public List<CaseTrackerDetailsEntity> findByCaseIdCustom(@Param("caseId") int caseId);
	
}
