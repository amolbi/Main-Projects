package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "V_UI_CASE_TRACKER_AUDIT" , schema = "UI")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CaseTimeTakenEntity {

	@Id
	private int caseId;
	private String startDateTime;
	private String endDateTime;
	private String totalProcessingTime;
	private String averageTime;

}
