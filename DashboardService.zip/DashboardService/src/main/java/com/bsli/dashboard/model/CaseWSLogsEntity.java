package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "T_CASE_WS_LOGS" , schema = "DBO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CaseWSLogsEntity {

	@Id
	private int id;
	private int caseId;
	private String logSource;
	private String logLevel;
	private String logEvent;
	private String processCd;
	private String activityStatus;
	private String activityData;
	private String logKeyId_1;
	private String logKeyId_2;

}
