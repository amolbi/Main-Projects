package com.bsli.dashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bsli.dashboard.model.ListIQCSTPKittyEntity;

public interface ListIQCSTPKittyRepository extends JpaRepository<ListIQCSTPKittyEntity, Integer>{
	
	
	
	@Query(value="SELECT * FROM [UI].[V_UI_LIST_IQC_STP_KITTY_TOP] ORDER BY APP_CREATE_DT DESC",nativeQuery=true)
	public List<ListIQCSTPKittyEntity> findTopByNumber(); 
}