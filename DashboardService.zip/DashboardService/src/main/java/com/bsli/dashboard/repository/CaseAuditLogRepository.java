package com.bsli.dashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bsli.dashboard.model.CaseAuditLogsEntity;

public interface CaseAuditLogRepository extends JpaRepository<CaseAuditLogsEntity, Integer>
{
	@Query(value="SELECT * FROM UI.V_UI_CASE_TRACKER_AUDIT_DETAILS p WHERE p.case_Id = :caseId",nativeQuery=true)
	public List<CaseAuditLogsEntity> findByCaseIdCustom(@Param("caseId") int caseId);
	
}
