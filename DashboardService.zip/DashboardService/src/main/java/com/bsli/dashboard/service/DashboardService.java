package com.bsli.dashboard.service;

import java.util.List;
import java.util.Optional;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsli.dashboard.model.DashboardFilter;
import com.bsli.dashboard.repository.DashboardFilterRepository;

@Service
public class DashboardService {
	@Autowired
	private DashboardFilterRepository dashboardFilterRepository;
	
	public String getFilterOptions() {
		JSONArray mainArray = new JSONArray();
		JSONObject planPolType = new JSONObject();
		JSONObject channelJson = new JSONObject();
		JSONObject kittyJson = new JSONObject();

		List<DashboardFilter> planPolTyp = dashboardFilterRepository.findByCategory("PLAN_POL_TYPE");

		if (Optional.ofNullable(planPolTyp).isPresent()) {
			try {
			planPolType.put("option", "Product Type");
			JSONArray planPolTypeArray = new JSONArray();
			for(DashboardFilter f : planPolTyp)
			{
				JSONObject ob = new JSONObject();
				try {
					ob.put("value", f.getCode());
					ob.put("key",f.getDescription());
					planPolTypeArray.put(ob);
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
			planPolType.put("suboption", planPolTypeArray);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			mainArray.put(planPolType);
		}
		List<DashboardFilter> channel = dashboardFilterRepository.findByCategory("APP_SOURCE");
		if (Optional.ofNullable(channel).isPresent()) {
			try {
			channelJson.put("option", "Channel");
			JSONArray channelArray = new JSONArray();
			for(DashboardFilter f : channel)
			{
				JSONObject ob = new JSONObject();
				try {
					ob.put("value", f.getCode());
					ob.put("key",f.getDescription());
					channelArray.put(ob);
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
			channelJson.put("suboption", channelArray);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			mainArray.put(channelJson);
		}
		List<DashboardFilter> pendingKitty = dashboardFilterRepository.findByCategory("PENDING_KITTY");
		if (Optional.ofNullable(pendingKitty).isPresent()) {
			try {
			kittyJson.put("option", "Pneding Kitty");
			JSONArray kittyArray = new JSONArray();
			for(DashboardFilter f : pendingKitty)
			{
				JSONObject ob = new JSONObject();
				try {
					ob.put("value", f.getCode());
					ob.put("key",f.getDescription());
					kittyArray.put(ob);
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
			kittyJson.put("suboption", kittyArray);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			mainArray.put(kittyJson);
		}
		return mainArray.toString();
	}
}
