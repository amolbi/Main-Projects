package com.bsli.dashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bsli.dashboard.model.CaseAuditLogsEntity;
import com.bsli.dashboard.model.CaseTrackerTableEntity;

public interface CaseTrackerTableRepository extends JpaRepository<CaseTrackerTableEntity, Integer>
{
//	@Query(value="SELECT * FROM UI.V_UI_CASE_TRACKER_AUDIT_DETAILS ",nativeQuery=true)
//	public List<CaseTrackerTableEntity> findByCaseIdCustom();
	
	@Query(value="select * from ui.V_UI_LIST_CASE_TRACKER_TABLE where CASE_STATUS like '%PENDING%'",nativeQuery=true)
	public List<CaseTrackerTableEntity> allPendingCases();
	
	@Query(value="select * from ui.V_UI_LIST_CASE_TRACKER_TABLE_POLICY_CREATED",nativeQuery=true)
	public List<CaseTrackerTableEntity> viewMorePolicyCreatedList();
	
	@Query(value="select * from ui.V_UI_LIST_CASE_TRACKER_TABLE_PENDING_FOR_RWS",nativeQuery=true)
	public List<CaseTrackerTableEntity> viewMorePendingForRWSList();
	
	@Query(value="select * from ui.V_UI_LIST_CASE_TRACKER_TABLE_PENDING_FOR_AURA",nativeQuery=true)
	public List<CaseTrackerTableEntity> viewMorePendingForAURAList();
	
	@Query(value="select * from ui.V_UI_LIST_CASE_TRACKER_TABLE_PENDING_FOR_POSIDEX_DEC",nativeQuery=true)
	public List<CaseTrackerTableEntity> viewMorePendingForPosidexDecisionList();
	
	@Query(value="select * from ui.V_UI_LIST_CASE_TRACKER_TABLE_PENDING_FOR_IQC",nativeQuery=true)
	public List<CaseTrackerTableEntity> viewMorePendingForIQCDecisionList();
	
	@Query(value="select * from ui.V_UI_LIST_CASE_TRACKER_TABLE_AIS",nativeQuery=true)
	public List<CaseTrackerTableEntity> viewMoreAISList();

	@Query(value="select * from ui.V_UI_LIST_CASE_TRACKER_TABLE_STUCK_CASES",nativeQuery=true)
	public List<CaseTrackerTableEntity> viewMoreStuckCasesList();

	@Query(value="select * from ui.V_UI_LIST_CASE_TRACKER_TABLE_PENDING_PIVC",nativeQuery=true)
	public List<CaseTrackerTableEntity> viewMoreStuckPendingForPIVCList();
	
}
