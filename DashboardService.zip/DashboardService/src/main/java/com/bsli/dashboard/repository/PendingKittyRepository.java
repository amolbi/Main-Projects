package com.bsli.dashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bsli.dashboard.model.PendingKittyEntity;

public interface PendingKittyRepository extends JpaRepository<PendingKittyEntity, Integer>{
	
	@Query(value="SELECT  * FROM UI.V_UI_LIST_PENDING_KITTY ORDER BY APP_CREATE_DT ASC",nativeQuery=true)
	public List<PendingKittyEntity> findTopByNumber(); 
}