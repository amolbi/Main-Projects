package com.bsli.dashboard.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CaseTrackerRequest {

	private String caseId;
	private String caseParam;

	public boolean isValid() {
		return null != this.caseId && null != this.caseId;
	}
	
}
