package com.bsli.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "V_UI_CASE_TRACKER_DETAILS" , schema = "UI")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CaseTrackerDetailsEntity {

	@Id
	@JsonProperty("Case Id")
	private int caseId;
	@JsonProperty("Application Number")
	private String applicationNumber;
	@JsonProperty("App Source")
	private String appSource;
	@JsonProperty("App Sync")
	private String appSync;
	@JsonProperty("Receipt No.")
	private String receiptNo;
	@JsonProperty("Posidex Decision")
	private String posidexDecision;
	@JsonProperty("Client Id")
	private String clientId;
	@JsonProperty("Artivatic")
	private String artivtaic;
	@JsonProperty("UW Status")
	private String uwStatus;
	@JsonProperty("IQC")
	private String iqc;
	@JsonProperty("Policy Creation")
	private String policyCreation;
	@JsonProperty("Policy Id")
	private String policyId;
	@JsonProperty("RWS Sync")
	private String rwsSync;
	@JsonProperty("Money Management")
	private String moneyMan;
	@JsonProperty("PIVC")
	private String pivc;
	@JsonProperty("AIS")
	private String ais;
	@JsonProperty("Policy Issuance")
	private String policyIssuance;

}
