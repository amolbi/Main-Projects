package com.bsli.batch.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsli.batch.exception.RecordNotFoundException;
import com.bsli.batch.model.CmDownloadBatchEntity;
import com.bsli.batch.model.CmDownloadPolicyEntity;
import com.bsli.batch.repository.CmDownloadBatchRepository;
import com.bsli.batch.repository.CmDownloadPolicyRepository;

@Service
public class CMDownloadPolicyService {

	@Autowired
	private CmDownloadPolicyRepository cmDownloadPolicyRepository;

	public List<CmDownloadPolicyEntity> createOrUpdatePolicy(CmDownloadBatchEntity entity,
			List<String> totalListOfPolicies)
			throws RecordNotFoundException 
	{

		CmDownloadPolicyEntity policyEntity = null;
		List<CmDownloadPolicyEntity> policyEntityList = new ArrayList<CmDownloadPolicyEntity>();
		
		for(String policy : totalListOfPolicies)
		{
			policyEntity = new CmDownloadPolicyEntity();
			policyEntity.setBatchId(entity.getBatchId());
			policyEntity.setPolicyNumber(policy);
			policyEntity.setStartTime(new Timestamp(System.currentTimeMillis()));
			
			policyEntityList.add(policyEntity);
		}
		
		List<CmDownloadPolicyEntity> policyEntityListSaved = cmDownloadPolicyRepository.saveAll(policyEntityList);
		
		if(Optional.ofNullable(policyEntityListSaved).isPresent())
		{
			return policyEntityListSaved;
		}
		
		return policyEntityListSaved;
	}

}
