package com.bsli.batch.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bsli.batch.cm.CMSearchDocuments;
import com.bsli.batch.cm.DownloadImage;
import com.bsli.batch.model.CmDownloadBatchEntity;
import com.bsli.batch.model.CmDownloadPolicyEntity;
import com.bsli.batch.repository.CmDownloadPolicyRepository;
import com.ibm.mm.beans.CMBConnection;
import com.ibm.mm.beans.CMBSearchResults;

@Service
public class CMDocumentDownloadService {
	private static final Logger LOGGER = LoggerFactory.getLogger(CMDocumentDownloadService.class);

	@Autowired
	private CmDownloadPolicyRepository cmDownloadPolicyRepository;
	
	@Autowired
	private CMDownloadPolicyService cmDownloadPolicyService;
	
	@Async
	public CompletableFuture<List<String>> splitFile(
			List<String> listOfPoliciesToDownload
			)
	{
		LOGGER.debug(""+listOfPoliciesToDownload);
		return CompletableFuture.completedFuture(listOfPoliciesToDownload);
		
	}
	
	@Async
	public CompletableFuture<List<String>> downloadDocuments(
			List<String> listOfPoliciesToDownload,
			CmDownloadBatchEntity batchEntity,
			CMBConnection connection
			)
	{
		LOGGER.info("CMDocumentDownloadService.checkTreads() Start:"+listOfPoliciesToDownload);
		try {
			List<CmDownloadPolicyEntity> listPolicyEntity = cmDownloadPolicyService.
					createOrUpdatePolicy(batchEntity, listOfPoliciesToDownload);
			
			/*
			 * Thread.sleep(1 * // minutes to sleep 60 * // seconds to a minute 1000);
			 */
			
			CMSearchDocuments cmSearch = new CMSearchDocuments();
			
			
			for(CmDownloadPolicyEntity policy : listPolicyEntity)
			{
				int countOfDocuments = 0;
				try 
				{
					CMBSearchResults cmbrest = cmSearch.searchForDocumentsInCM(connection, 
							"(/POLAD_DOCUMENTS | /TMA | /RURALCLAIMDOC | /RURALAPPDOC | /HEALTHCLAIMS | /CLAIMSDOC | /POLDOCTEMP | /UNDWRTDOCTEMP | /MRSDOC | /CONFTEMP | /APPDOCTEMP | /POLICYDOC | /LOOSEMAILS | /APPDOC | /SIGNDOC | /CONFSDOC | /UNDWRTDOC)[(@PolicyNumber = \""+policy.getPolicyNumber()+"\") ]");
						
					if(cmbrest.getCount()>0)
					{
						DownloadImage downloadImage = new DownloadImage();
						downloadImage.startDownload(cmbrest, 
								connection, 
								"D:\\DOC_OUTPUT\\Output\\", 
								policy.getPolicyNumber());
						
					}
					countOfDocuments = cmbrest.getCount();
						
//						System.out.println("CM Count is "+cmbrest.getCount());
						
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				policy.setDocumentCount(countOfDocuments);
				policy.setEndTime(new Timestamp(System.currentTimeMillis()));
				policy.setFolderPath("D:\\DOC_OUTPUT\\Output\\");
				
				cmDownloadPolicyRepository.save(policy);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		LOGGER.info("CMDocumentDownloadService.checkTreads() Finish:"+listOfPoliciesToDownload);
		return CompletableFuture.completedFuture(listOfPoliciesToDownload);
	}
}
