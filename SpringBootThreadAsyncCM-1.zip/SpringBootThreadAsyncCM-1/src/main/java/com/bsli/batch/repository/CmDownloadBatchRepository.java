package com.bsli.batch.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bsli.batch.model.CmDownloadBatchEntity;

@Repository
public interface CmDownloadBatchRepository extends JpaRepository<CmDownloadBatchEntity, Long>{

	
}
