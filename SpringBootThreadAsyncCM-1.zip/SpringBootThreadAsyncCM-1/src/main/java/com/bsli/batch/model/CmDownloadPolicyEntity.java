package com.bsli.batch.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="CM_DOWNLOAD_POLICY")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CmDownloadPolicyEntity {

	@Id
	@Column(name="ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
	@Column(name="BATCH_ID")
    private Long batchId;
    
    @Column(name="POLICY_NUMBER")
    private String policyNumber;
    
    @Column(name="START_TIME")
    private Timestamp startTime;
    
    @Column(name="END_TIME")
    private Timestamp endTime;
        
    @Column(name="DOCUMENT_COUNT")
    private int documentCount;
    
    @Column(name="FOLDER_PATH")
    private String folderPath;
    
    @Column(name="THREAD_ID")
    private String threadId;
}
