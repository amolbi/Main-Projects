package com.bsli.batch.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.web.multipart.MultipartFile;

public class FileUtil {
	
	public static List readByJava8(String fileName) throws IOException {
        List<String> result;
        try (Stream<String> lines = Files.lines(Paths.get(fileName))) {
            result = lines.collect(Collectors.toList());
        }
        return result;

    }
	public static List readByJava8(MultipartFile multipartFile) throws IOException {
        List<String> result = new ArrayList<>();
        File convFile = new File(System.getProperty("java.io.tmpdir")+"/"+multipartFile.getName());
        multipartFile.transferTo(convFile);
        
        try (Stream<String> lines = Files.lines(Paths.get(convFile.toURI()))) {
            result = lines.collect(Collectors.toList());
        }
        
        return result;

    }
	
	    static long heavy;

	    public static List<String> pullSize(String path) {
	    	List<String> str = new ArrayList<>();
	        File file = new File(path);
	        File dirs = null;

	        if (file.isDirectory()) {
	            File[] filesNames = file.listFiles();
	            for (File temp : filesNames) {
	                if (temp.isDirectory()) {
	                    dirs = new File(temp.getPath());
	                    heavy += getDirSize(dirs);
	                } else {
	                	str.add("FILE - " + temp.getPath() + " "
	                            + friendlyFileSize(temp.length()));
	                    System.out.println("FILE - " + temp.getPath() + " "
	                            + friendlyFileSize(temp.length()));
	                }
	            }
	        } else {
	            System.out.println("THIS IS NOT A FILE LOCATION!");
	        }
	        str.add("DIR - " + dirs.getParent() + " "
	                + friendlyFileSize(heavy));
	        System.out.println("DIR - " + dirs.getParent() + " "
	                + friendlyFileSize(heavy));
	        return str;
	    }

	    private static long getDirSize(File dirs) {
	        long size = 0;
	        if (dirs != null && dirs.listFiles() != null) {
	            for (File file : dirs.listFiles()) {
	                if (file.isFile())
	                    size += file.length();
	                else
	                    size += getDirSize(file);
	            }
	        }

	        return size;

	    }

	    public static String friendlyFileSize(long size) {
	        String unit = "bytes";
	        if (size > 1024) {
	            size = size / 1024;
	            unit = "kb";
	        }
	        if (size > 1024) {
	            size = size / 1024;
	            unit = "mb";
	        }
	        if (size > 1024) {
	            size = size / 1024;
	            unit = "gb";
	        }
	        return " (" + size + ")" + unit;
	    }
	    
	    public static void main(String[] args) {
			pullSize("C:\\AmolB\\Git");
		}
}
