package com.bsli.batch.listner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;



@Component
public class StartupApplicationListener implements ApplicationListener<ContextRefreshedEvent>
{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(StartupApplicationListener.class);
	
	@Value("${CM_DSTYPE}")
	private String dsType;
//	CMConnectionPool cmConnectionPool;  
	
//	@Autowired
//	private CMConnectionPool cmConnectionPool;
	
//	@Autowired
//	private CMBConnectionPool cmbConnectionPool;
	
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		
		LOGGER.info("Started-"+dsType);
		/*CMConnectionPool cmConnectionPool;
		 System.out.println("Getting connection from CM Pool...");
		    if (this.cmbConnectionPool == null) {
		      LOGGER.info("cmbConnectionPool was null, creating new cmbConnectionPool.");
		      cmConnectionPool = new CMConnectionPool();
		      cmbConnectionPool = cmConnectionPool.getConnection();
		    } 
		    System.out.println("Existing CMBConnectionPool returned...");*/
	}

	
}
