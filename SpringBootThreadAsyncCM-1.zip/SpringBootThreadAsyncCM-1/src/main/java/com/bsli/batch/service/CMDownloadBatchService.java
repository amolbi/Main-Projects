package com.bsli.batch.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsli.batch.exception.RecordNotFoundException;
import com.bsli.batch.model.CmDownloadBatchEntity;
import com.bsli.batch.model.CmDownloadPolicyEntity;
import com.bsli.batch.repository.CmDownloadBatchRepository;

@Service
public class CMDownloadBatchService {
	
	@Autowired
	private CmDownloadBatchRepository cmDownloadBatchRepository;
	
	public CmDownloadBatchEntity createOrUpdateBatch(
			List<String> totalListOfPolicies,
			String userId, 
			String status,
			int batchId
			) throws RecordNotFoundException
    {
		Optional entityObject = cmDownloadBatchRepository.findById(Long.valueOf(batchId));
		CmDownloadBatchEntity entity = null;
		if(entityObject.isPresent())
		{
			entity = (CmDownloadBatchEntity) entityObject.get();
			if("C".equals(status)) {
				entity.setEndTime(new Timestamp(System.currentTimeMillis()));
				entity.setBatchStatus(status);
				entity = cmDownloadBatchRepository.save(entity);
			}
			
		}else 
		{
			entity = new CmDownloadBatchEntity();
			entity.setCreatedBy(userId);
			entity.setBatchStatus(status);
			if("W".equals(status))
				entity.setStartTime(new Timestamp(System.currentTimeMillis()));
			
			entity.setPolicyCountInput(totalListOfPolicies.size());
			
			entity = cmDownloadBatchRepository.save(entity);
			
			
		}
		
        return entity;
    }
     
}
