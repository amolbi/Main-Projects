package com.bsli.batch.controller;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bsli.batch.cm.CMSearchDocuments;
import com.bsli.batch.cm.DownloadImage;
import com.bsli.batch.exception.RecordNotFoundException;
import com.bsli.batch.listner.CMConnectionPool;
import com.bsli.batch.model.CmDownloadBatchEntity;
import com.bsli.batch.service.CMDownloadBatchService;
import com.bsli.batch.service.ThreadService;
import com.bsli.batch.util.FileUtil;
import com.ibm.mm.beans.CMBSearchResults;

@RestController
@RequestMapping("/api/thread")
public class ThreadController 
{
	private static final Logger LOGGER = LoggerFactory.getLogger(ThreadController.class);

	@Autowired
	private ThreadService threadService;
	
	@Autowired
	private CMDownloadBatchService cmDownloadBatchService;
	
	@Value("${CM_DSTYPE}")
	private String dsType;
	
	@Value("${CM_SERVERNAME}")
	private String serverName;
	
	@Value("${CM_USERID}")
	private String userId;
	
	@Value("${CM_PASSWORD}")
	private String password;
	
	@Value("${CM_MAX_CONNECTIONS}")
	private String maxConnection;
	
	@Value("${CM_ICMENVFILE}")
	private String icmenvfile;
	
	@Value("${CM_ICMSERVERSFILE}")
	private String icmsrvfile;
	
	@Value("${CM_MAX_FREE_CONNECTIONS}")
	private String maxFreeConn;
	
//	@Autowired
//	private CMBConnectionPool cmbConnectionPool;
	
//	@Autowired
//	private CMBConnection cmbConnection;

	@GetMapping("/checkThreads/{appNumber}")
	// consumes={MediaType.APPLICATION_JSON_VALUE},
	// produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody CompletableFuture<ResponseEntity> checkThreadsMethod(@PathVariable("appNumber") String appNumber) {
		ArrayList<Integer> list = new ArrayList<>();
		
		String filename = "D:\\DOC_OUTPUT\\Input\\input.txt";
		String newFileName = "D:\\DOC_OUTPUT\\Input\\completed.txt";

        try {
            List listF = FileUtil.readByJava8(filename);
            String ss = "";
//            list.forEach(ss);
            
            
            Files.write(Paths.get(newFileName), listF.toString().getBytes(StandardCharsets.UTF_8), 
            		 StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
		
		for (int i = 1; i <= 10; i++) {
			list.add(i);
		}
		System.out.println("TT:"+dsType);
		HashMap<String, String> connectionProperteisMap = new HashMap<>();
		connectionProperteisMap.put("CM_DSTYPE", dsType);
		connectionProperteisMap.put("CM_SERVERNAME", serverName);
		connectionProperteisMap.put("CM_USERID", userId);
		connectionProperteisMap.put("CM_PASSWORD", password);
		connectionProperteisMap.put("CM_MAX_CONNECTIONS", maxConnection);
		connectionProperteisMap.put("CM_ICMENVFILE", icmenvfile);
		connectionProperteisMap.put("CM_ICMSERVERSFILE", icmsrvfile);
		connectionProperteisMap.put("CM_MAX_FREE_CONNECTIONS", maxFreeConn);
		
		CMConnectionPool cmConnectionPool = new CMConnectionPool(connectionProperteisMap);
//		cmbConnectionPool = cmConnectionPool.getConnection();
		
		CMSearchDocuments cmSearch = new CMSearchDocuments();
		try 
		{
			CMBSearchResults cmbrest = cmSearch.searchForDocumentsInCM(cmConnectionPool.connection, "(/POLAD_DOCUMENTS | /TMA | /RURALCLAIMDOC | /RURALAPPDOC | /HEALTHCLAIMS | /CLAIMSDOC | /POLDOCTEMP | /UNDWRTDOCTEMP | /MRSDOC | /CONFTEMP | /APPDOCTEMP | /POLICYDOC | /LOOSEMAILS | /APPDOC | /SIGNDOC | /CONFSDOC | /UNDWRTDOC)[(@PolicyNumber = \""+appNumber+"\") ]");
				
			if(cmbrest.getCount()>0)
			{
				DownloadImage downloadImage = new DownloadImage();
				downloadImage.startDownload(cmbrest, cmConnectionPool.connection, "D:\\DOC_OUTPUT\\Output\\", appNumber);
				
			}
				
				System.out.println("CM Count is "+cmbrest.getCount());
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("CarController.checkThreadsMethod()" + list.size());

		ArrayList<CompletableFuture<ArrayList<Integer>>> responseList = new ArrayList<CompletableFuture<ArrayList<Integer>>>();

		for (Integer in : list) {
			responseList.add(threadService.checkTreads(in));
		}

		CompletableFuture<ArrayList<CompletableFuture<ArrayList<Integer>>>> aa = CompletableFuture
				.completedFuture(responseList);
		return aa.<ResponseEntity>thenApply(ResponseEntity::ok);
	}
	
	@PostMapping("/startBatch")
    public ResponseEntity<CmDownloadBatchEntity> createOrUpdateEmployee(CmDownloadBatchEntity cmDownloadBatchEntity)
                                                    throws RecordNotFoundException {
		System.out.println(cmDownloadBatchEntity);
		
		cmDownloadBatchEntity = new CmDownloadBatchEntity();
		cmDownloadBatchEntity.setStartTime(new Timestamp(System.currentTimeMillis()));
		cmDownloadBatchEntity.setCreatedBy("Amol");
		cmDownloadBatchEntity.setBatchStatus("R");
		cmDownloadBatchEntity.setPolicyCountInput(1000);
		CmDownloadBatchEntity updated = cmDownloadBatchService.createOrUpdateBatch(null, userId, dsType, 0);
        return new ResponseEntity<CmDownloadBatchEntity>(updated, new HttpHeaders(), HttpStatus.OK);
        
    }

}
