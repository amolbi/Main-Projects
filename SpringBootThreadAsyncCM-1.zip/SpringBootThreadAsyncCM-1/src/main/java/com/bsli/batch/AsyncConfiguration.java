package com.bsli.batch;

import java.util.concurrent.Executor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
@EnableAsync
public class AsyncConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(AsyncConfiguration.class);
    
    @Value("${THREAD_COUNT}")
	private String threadCount;
    @Value("${THREAD_POOL_SIZE}")
	private String threadPoolSize;

    @Bean (name = "taskExecutor")
    public Executor taskExecutor() {
    	LOGGER.info("Default Thread capacity::"+threadCount);
        LOGGER.info("Creating Async Task Executor");
        final ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(Integer.parseInt(threadPoolSize));
        executor.setMaxPoolSize(Integer.parseInt(threadCount));
        executor.setQueueCapacity(Integer.parseInt(threadCount));
        executor.setThreadNamePrefix("DocumentThread-");
        executor.initialize();
        System.out.println("AsyncConfiguration.taskExecutor()"+executor.getActiveCount());
        
        return executor;
    }

}
