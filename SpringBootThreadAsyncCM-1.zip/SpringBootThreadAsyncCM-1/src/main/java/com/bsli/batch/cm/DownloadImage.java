package com.bsli.batch.cm;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.mm.beans.CMBConnection;
import com.ibm.mm.beans.CMBDataManagement;
import com.ibm.mm.beans.CMBException;
import com.ibm.mm.beans.CMBItem;
import com.ibm.mm.beans.CMBObject;
import com.ibm.mm.beans.CMBSearchResults;

public class DownloadImage {
	private static final Logger LOGGER = LoggerFactory.getLogger(DownloadImage.class);
	
	private String FILE_SEPARATOR;
	
	public ArrayList<String> startDownload(
			CMBSearchResults cmbrest,CMBConnection conn,
			String documentDownloadRootDir,String polNo)
	{
		LOGGER.info("DownloadImage.startDownload() - DownloadDirectory:"+documentDownloadRootDir);
		ArrayList<String> listOfSuccessfullyDownlaodedDocuments = new ArrayList<>();
		String appNumber = "";
		try 
		{
				FILE_SEPARATOR = System.getProperty("file.separator");
			
			String policyNumberDir = "";
			CMBItem item = null;
			
			if(cmbrest.getCount()>0)
			{
//				listOfSuccessfullyDownlaodedDocuments = new ArrayList<>();
				
				for (int i =0; i < cmbrest.getCount(); i++)
				{
					
					String docName="";
					String formId = "";
//					String appNo ="";
					
					try 
					{
						item = cmbrest.getItem(i);
						String pid = item.getPidString();
						String name = item.getAttrValue("SubDocument");
						String MainDocument = item.getAttrValue("MainDocument");
						
						String policyNumber = item.getAttrValue("PolicyNumber");
						appNumber = item.getAttrValue("AppNumber");
						
						appNumber = appNumber == null || "".equals(appNumber) ? "" : appNumber.trim();
						
						if("".equals(policyNumber) || "000000000".equals(policyNumber))
						{
							policyNumberDir = "000000000";
							policyNumber = "000000000";
						}
						else
						{
							policyNumberDir = policyNumber;
						}
						formId = item.getAttrValue("FormID");
						
						
						String strCreateTimestamp = "";
						try {
							Timestamp tt = item.getCreateTimestamp();
							strCreateTimestamp = new SimpleDateFormat("ddMMyyyyHHmmss").format(tt);
						} catch (Exception e) 
						{
							strCreateTimestamp = ""+i;
						}
						
						if(name.indexOf("'") != -1)
						{
							name = name.replace("'", "");
						}
						if(name.indexOf('/') != -1)
						{
							name = name.replace('/', ' ');
						}
						if(MainDocument.indexOf("'") != -1)
						{
							MainDocument = MainDocument.replace("'", "");
						}
						if(MainDocument.indexOf('/') != -1)
						{
							MainDocument = MainDocument.replace('/', ' ');
						}
//						System.out.println(name+"||"+policyNumber+"||"+item.getName()+"||"+MainDocument);


						
//						System.out.println("In Folder: "+polDirectory.getAbsolutePath());
						File fileDate=new File(documentDownloadRootDir );
							if(!fileDate.isDirectory())
							{
								fileDate.mkdirs();
							}
						
						
						String folderNameBeforeReindexing = appNumber+"_000000000";
						
						File polDirectoryBeforeReindexing=new File(fileDate,System.getProperty("file.separator")+folderNameBeforeReindexing);
						
						String folderName = appNumber+"_"+policyNumberDir;
						
						File polDirectory=new File(fileDate,System.getProperty("file.separator")+folderName);
						String finalSFTPFilePath = "";
							if(polDirectoryBeforeReindexing.isDirectory()
									&& !"000000000".equals(policyNumber))
							{
								polDirectoryBeforeReindexing.renameTo(polDirectory);
							}
							
							if(!polDirectory.isDirectory())
							{
								polDirectory.mkdir();
							}
						
						docName=appNumber+"_"+policyNumber+"_"+formId+"_"+MainDocument+"_"+strCreateTimestamp;
						
						String fullFilePath = polDirectory.getAbsolutePath().trim()+FILE_SEPARATOR+docName;
						String fullFilePathTemp = "D:\\DOC_OUTPUT\\Output\\"+docName;
						LOGGER.info("Final fullFilePath::"+documentDownloadRootDir+FILE_SEPARATOR+folderName);
						
						
						
						boolean isDownloadDone = false;
//						if(!"NA".equalsIgnoreCase(cmDocumentDownloadURL))
//						{
//							isDownloadDone = downloadDocumentFromWS(pid, fullFilePath, cmDocumentDownloadURL);
//						}
//						else
//						{
							try 
							{
								CMBDataManagement dmanage=conn.getDataManagement();
								dmanage.setDataObject(item);
								dmanage.retrieveItem();
								CMBObject obj=dmanage.getContent(0);
								byte[] data;
								data=obj.getData();
									fullFilePath = fullFilePath+this.getExtType(obj);
								LOGGER.info("Temp Document Full Path-"+fullFilePath);
								File outfile=new File(fullFilePath);
								outfile.createNewFile();
								FileOutputStream fos=new FileOutputStream(outfile);
								BufferedOutputStream bos=new BufferedOutputStream(fos);
								DataOutputStream dos=new DataOutputStream(bos);
								
								dos.write(data, 0, data.length);
								dos.flush();					
								dos.close();
								bos.flush();
								bos.close();
								fos.flush();
								fos.close();
								boolean tempIsDownloadDone = false;
								if(outfile.exists())
									tempIsDownloadDone = true;
								
								
								
								isDownloadDone = tempIsDownloadDone;
							} 
							catch (Exception e) 
							{
								e.printStackTrace();
								isDownloadDone = false;
							}
//						}
						LOGGER.info("isDownloadDone::"+isDownloadDone);
						
						if(isDownloadDone)
						{
							listOfSuccessfullyDownlaodedDocuments.add(fullFilePath);
						}
					
					}catch (Exception e) {
						
						LOGGER.error("Exception while fetching details from CM", e);
						e.printStackTrace();
					}
					
				}
				
			}
			else{
				LOGGER.debug("No Search Results found in CM for Pol No. "+appNumber);	
			}
			
			
			}  catch (Exception e) {
				LOGGER.error("Exception in startDownload()", e);
				e.printStackTrace();
		}
		return listOfSuccessfullyDownlaodedDocuments;
	}
	public String getExtType(CMBObject obj) throws CMBException{
		String fileExtension=null;
		
		if(obj.getMimeType().equalsIgnoreCase("image/tiff")){
			fileExtension=".tiff";
		}
		else if (obj.getMimeType().equalsIgnoreCase("application/pdf")) {
			fileExtension=".pdf";
		}
		else if (obj.getMimeType().equalsIgnoreCase("text/plain")) {
			fileExtension=".txt";
		}
		else if (obj.getMimeType().equalsIgnoreCase("image/jpeg")) {
			fileExtension=".jpg";
		}
		else if (obj.getMimeType().equalsIgnoreCase("image/bmp")) {
			fileExtension=".bmp";
		}
		else if (obj.getMimeType().equalsIgnoreCase("text/richtext")) {
			fileExtension=".rtf";
		}
		return fileExtension;
	}
	
	public static boolean downloadDocumentFromWS(String pid, String fileName)
	{
		try {
			String strUrl = "";
//			logger.info("CM DOC DOWNLOAD URL : "+strUrl);
			LOGGER.info("CM DOC DOWNLOAD pid : "+pid);
			try
			{
				pid=  URLEncoder.encode(pid, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			URL url = new URL(strUrl+pid);
			
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");
//			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));

//			String output;
//			System.out.println("Output from Server .... \n");
			/*while ((output = br.readLine()) != null) {
				System.out.println(output);
			}*/
			
			String cType = "";
			
			for (Entry<String, List<String>> header : conn.getHeaderFields().entrySet()) {
//			    System.out.println(header.getKey() + "=" + header.getValue());
			    if(("Content-Type").equalsIgnoreCase(header.getKey()))
			    {
			    	cType = header.getValue().get(0);
			    }
			}
			InputStream is ;
			is = conn.getInputStream();
			
			 try (InputStream inputStream = is) 
			 {
//				 String fileName = "d:\\log\\";
				 if(cType.contains("tiff"))
				 {
					 fileName = fileName+".tiff";
				 }
				 else if(cType.contains("pdf"))
				 {
					 fileName = fileName+".pdf";
				 }
				 else if(cType.contains("jpg"))
				 {
					 fileName = fileName+".jpg";
				 }
				 else if(cType.contains("jpeg"))
				 {
					 fileName = fileName+".jpeg";
				 }
				 else if (cType.contains("bmp")) 
				 {
					 fileName = fileName+".bmp";
				 }
				 
				 File file = new File(fileName);
//				 System.out.println("Downloaded File : "+fileName);
		          
		         copyInputStreamToFile(inputStream, file);
		     }
			conn.disconnect();
			return true;

		  } catch (MalformedURLException e) {

			e.printStackTrace();
			LOGGER.error("Exception while fetching details from CM", e);

		  } catch (IOException e) {

			e.printStackTrace();
			LOGGER.error("Exception while fetching details from CM", e);

		  }
		return false;
	}
	private static void copyInputStreamToFile(InputStream inputStream, File file) 
			throws IOException {

		try (FileOutputStream outputStream = new FileOutputStream(file)) {

			int read;
			byte[] bytes = new byte[1024];

			while ((read = inputStream.read(bytes)) != -1) {
				outputStream.write(bytes, 0, read);
			}

			// commons-io
			//IOUtils.copy(inputStream, outputStream);

		}

	}
}


