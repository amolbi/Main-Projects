package com.bsli.batch.listner;

import java.beans.PropertyVetoException;
import java.net.MalformedURLException;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.ibm.mm.beans.CMBBaseConstant;
import com.ibm.mm.beans.CMBConnection;
import com.ibm.mm.beans.CMBConnectionPool;
import com.ibm.mm.beans.CMBException;

/**
 * Connection pooling.
 */
public class CMConnectionPool {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CMConnectionPool.class);
	
	public static CMBConnectionPool connectionPool;
	public CMBConnection connection;

	@Value("${CM_DSTYPE}")
	private String dsType;
	
	@Value("${CM_SERVERNAME}")
	private String serverName;
	
	@Value("${CM_USERID}")
	private String userId;
	
	@Value("${CM_PASSWORD}")
	private String password;
	
	@Value("${CM_MAX_CONNECTIONS}")
	private String maxConnection;
	
	@Value("${CM_ICMENVFILE}")
	private String icmenvfile;
	
	@Value("${CM_ICMSERVERSFILE}")
	private String icmsrvfile;
	
	@Value("${CM_MAX_FREE_CONNECTIONS}")
	private String maxFreeConn;
	
	public CMConnectionPool(HashMap<String, String> connectionPropertiesMap) {
		this.dsType = connectionPropertiesMap.get("CM_DSTYPE");
		this.serverName = connectionPropertiesMap.get("CM_SERVERNAME");
		this.userId = connectionPropertiesMap.get("CM_USERID");
		this.password = connectionPropertiesMap.get("CM_PASSWORD");
		this.maxConnection = connectionPropertiesMap.get("CM_MAX_CONNECTIONS");
		this.icmenvfile = connectionPropertiesMap.get("CM_ICMENVFILE");
		this.icmsrvfile = connectionPropertiesMap.get("CM_ICMSERVERSFILE");
		this.maxFreeConn = connectionPropertiesMap.get("CM_MAX_FREE_CONNECTIONS");
		getConnection();
	}
	
	/**
	 * Obtains a connection from the connection pool. If a connection does not
	 * exist, a new one is established.
	 */
	public synchronized CMBConnectionPool getConnection() {
//		CMBConnection connection=null;
		try {
			

			if (connectionPool == null) {
				System.out.println(icmenvfile);
				System.out.println(icmsrvfile);
				LOGGER.debug("Creating new bean connection Pool ... ");
				connectionPool = new CMBConnectionPool();
				connectionPool
					.setConnectionType(CMBBaseConstant.CMB_CONNTYPE_LOCAL);
				connectionPool
					.setServiceConnectionType(CMBBaseConstant.CMB_CONNTYPE_LOCAL);
				connectionPool.setClientURLString(null);
				connectionPool.setCsURLString(null);
				connectionPool.setServiceClientURLString(null);
				connectionPool.setServiceCsURLString(null);
				connectionPool.setDsType(dsType);
				connectionPool.setServerName(serverName);
				connectionPool.setMaxConnections(Integer.parseInt(maxConnection));
				connectionPool
					.setMaxConnectionBehavior(CMBConnectionPool.CMB_MAX_CONNECTIONS_ERROR);
				connectionPool.setMaxFreeConnections(10);
			
				connectionPool.setConfigurationString("ICMENVFILE=(" + icmenvfile
						+ ")");
			
				connectionPool.setConfigurationString("ICMSERVERSFILE=("
					+ icmsrvfile + ")");
				// connectionPool.setMinFreeConnections(3);
				connectionPool.setTimeOut(30000);
			}
		
			connection = connectionPool.getConnection(userId,
				password);
			LOGGER.debug("Returning CMBConnection");
		
		} catch (CMBException e) {
			LOGGER.error("CMBException in getConnection() ", e);
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			LOGGER.error("CMBException in getConnection() ", e);
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			LOGGER.error("CMBException in getConnection() ", e);
			e.printStackTrace();
		} catch (InstantiationException e) {
			LOGGER.error("CMBException in getConnection() ", e);
			e.printStackTrace();
		} catch (MalformedURLException e) {
			LOGGER.error("CMBException in getConnection() ", e);
			e.printStackTrace();
		} catch (NoClassDefFoundError e) {
			LOGGER.error("CMBException in getConnection() ", e);
			e.printStackTrace();
		} catch (PropertyVetoException e) {
			LOGGER.error("CMBException in getConnection() ", e);
			e.printStackTrace();
		} catch (Exception e) {
			LOGGER.error("CMBException in getConnection() ", e);
			e.printStackTrace();
		}
		return connectionPool;

	}

	/**
	 * Returns a connection to the connection pool.
	 */
	public static synchronized void freeConnection(CMBConnection connection) {
		LOGGER.info("Releasing CM Connection");
		connectionPool.freeConnection(connection);
		
	}

	/**
	 * @throws CMBException
	 */
	public static synchronized void destroyPool() throws CMBException {
		LOGGER.info("CM Pool Destroyed");
		if (connectionPool != null) {
			connectionPool.destroy();
			connectionPool = null;
		}
	}

}
