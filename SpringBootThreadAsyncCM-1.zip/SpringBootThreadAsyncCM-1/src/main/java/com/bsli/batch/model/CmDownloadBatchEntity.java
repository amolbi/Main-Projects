package com.bsli.batch.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="CM_DOWNLOAD_BATCH")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CmDownloadBatchEntity {

	@Id
	@Column(name="BATCH_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long batchId;
    
    @Column(name="START_TIME")
    private Timestamp startTime;
    
    @Column(name="END_TIME")
    private Timestamp endTime;
    
    @Column(name="BATCH_STATUS")
    private String batchStatus;
    
    @Column(name="CREATED_BY")
    private String createdBy;
    
    @Column(name="POLICY_COUNT_INPUT")
    private int policyCountInput;
    
    @Column(name="POLICY_COUNT_OUTPUT")
    private int policyCountOutput;
}
