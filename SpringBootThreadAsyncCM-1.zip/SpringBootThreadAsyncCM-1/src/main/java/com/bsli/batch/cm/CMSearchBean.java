package com.bsli.batch.cm;

import java.util.Date;

import com.ibm.mm.beans.CMBItem;

public class CMSearchBean {
	
	  Date createTimestamp;
	  
	  CMBItem cmbItem;
	  
	  public Date getCreateTimestamp() {
	    return this.createTimestamp;
	  }
	  
	  public void setCreateTimestamp(Date createTimestamp) {
	    this.createTimestamp = createTimestamp;
	  }
	  
	  public CMBItem getCmbItem() {
	    return this.cmbItem;
	  }
	  
	  public void setCmbItem(CMBItem cmbItem) {
	    this.cmbItem = cmbItem;
	  }
	  
	  public String toString() {
	    return "CMSearchBean [createTimestamp=" + this.createTimestamp + ", cmbItem=" + this.cmbItem + "]";
	  }

}
