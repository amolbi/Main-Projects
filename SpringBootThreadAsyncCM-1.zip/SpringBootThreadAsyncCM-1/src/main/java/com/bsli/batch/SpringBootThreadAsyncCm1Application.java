package com.bsli.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootThreadAsyncCm1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootThreadAsyncCm1Application.class, args);
	}

}
