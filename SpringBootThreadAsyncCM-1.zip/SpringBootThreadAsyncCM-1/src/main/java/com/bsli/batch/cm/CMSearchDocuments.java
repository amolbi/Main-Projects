package com.bsli.batch.cm;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.mm.beans.CMBBaseConstant;
import com.ibm.mm.beans.CMBConnectFailedException;
import com.ibm.mm.beans.CMBConnection;
import com.ibm.mm.beans.CMBException;
import com.ibm.mm.beans.CMBInvalidQueryException;
import com.ibm.mm.beans.CMBQueryService;
import com.ibm.mm.beans.CMBSearchResults;


public class CMSearchDocuments {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CMSearchDocuments.class);

  	
	public CMBSearchResults searchForDocumentsInCM(CMBConnection connection,String cmQuery) throws CMBInvalidQueryException, CMBConnectFailedException, 
			CMBException,CustomException{
					
		
		CMBSearchResults documents = new CMBSearchResults();
		
		
		try{
			LOGGER.info("Inside searchForDocumentsInCM() of CMSearchDocuments");
				
		    LOGGER.info("Final Query String for CM is::"+cmQuery);
		   
		
	
			 
			
			CMBQueryService queryService = connection.getQueryService();
			short queryType = CMBBaseConstant.CMB_QS_TYPE_XPATH;
			
			queryService.setQueryString(cmQuery, queryType);
			queryService.setAsynchSearch(false);
			// Perform search and create results set
			queryService.runQuery();
			
			documents.setConnection(connection);
			
			documents.newResults(queryService.getResults());			
			
		}catch(Exception ex){
			ex.printStackTrace();
			LOGGER.error("Error in searchForDocumentsInCM():: ", ex);
		}
		
		return documents;
	}
	

	
}
