package com.bsli.batch.config;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bsli.batch.listner.CMConnectionPool;

@Configuration
public class CMConfiguration {

	@Value("${CM_DSTYPE}")
	private String dsType;
	
	@Value("${CM_SERVERNAME}")
	private String serverName;
	
	@Value("${CM_USERID}")
	private String userId;
	
	@Value("${CM_PASSWORD}")
	private String password;
	
	@Value("${CM_MAX_CONNECTIONS}")
	private String maxConnection;
	
	@Value("${CM_ICMENVFILE}")
	private String icmenvfile;
	
	@Value("${CM_ICMSERVERSFILE}")
	private String icmsrvfile;
	
	@Value("${CM_MAX_FREE_CONNECTIONS}")
	private String maxFreeConn;
	
	@Bean
	public CMConnectionPool prepareConnectionPool()
	{
		HashMap<String, String> connectionProperteisMap = new HashMap<>();
		connectionProperteisMap.put("CM_DSTYPE", dsType);
		connectionProperteisMap.put("CM_SERVERNAME", serverName);
		connectionProperteisMap.put("CM_USERID", userId);
		connectionProperteisMap.put("CM_PASSWORD", password);
		connectionProperteisMap.put("CM_MAX_CONNECTIONS", maxConnection);
		connectionProperteisMap.put("CM_ICMENVFILE", icmenvfile);
		connectionProperteisMap.put("CM_ICMSERVERSFILE", icmsrvfile);
		connectionProperteisMap.put("CM_MAX_FREE_CONNECTIONS", maxFreeConn);
		System.out.println("CMConfiguration.prepareConnectionPool():"+connectionProperteisMap);
		
		CMConnectionPool cmConnectionPool = new CMConnectionPool(connectionProperteisMap);
		
		return cmConnectionPool;
	}
}
