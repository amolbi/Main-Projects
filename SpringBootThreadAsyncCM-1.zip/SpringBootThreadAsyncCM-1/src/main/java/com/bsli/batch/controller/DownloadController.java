package com.bsli.batch.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.bsli.batch.config.CMConfiguration;
import com.bsli.batch.model.CmDownloadBatchEntity;
import com.bsli.batch.model.CmDownloadPolicyEntity;
import com.bsli.batch.model.ResponseMessage;
import com.bsli.batch.service.CMDocumentDownloadService;
import com.bsli.batch.service.CMDownloadBatchService;
import com.bsli.batch.service.CMDownloadPolicyService;
import com.bsli.batch.util.FileUtil;
import com.google.common.collect.Lists;
import com.ibm.mm.beans.CMBConnection;

@Controller
@RequestMapping("/api/download")
public class DownloadController 
{

	private static final Logger LOGGER = LoggerFactory.getLogger(DownloadController.class);
			
	@Value("${THREAD_COUNT}")
	private String threadCount;
	
	@Autowired
	private CMDownloadBatchService cmDownloadBatchService;
	@Autowired
	private CMDownloadPolicyService cmDownloadPolicyService;
	@Autowired
	private CMDocumentDownloadService cmDocumentDownloadService;
	@Autowired
	private CMConfiguration cmConfiguration;
	
	@PostMapping("/upload-input-file")
	  public ResponseEntity<ResponseMessage> uploadFile(
			  @RequestParam("file") MultipartFile file,
			  @RequestParam("userId") String userId)
	{
		String message = "";
		CMBConnection connection;
		try 
		{
			connection = cmConfiguration.prepareConnectionPool().connection;

			List<String> listOfPolicies = FileUtil.readByJava8(file);

			CmDownloadBatchEntity batchEntity = cmDownloadBatchService.createOrUpdateBatch(
					listOfPolicies,
					userId,
					"W",
					0);


			System.out.println("Total Input Policies:"+listOfPolicies.size());

			for (List<String> partition : Lists.partition(listOfPolicies, Integer.parseInt(threadCount))) {
				cmDocumentDownloadService.downloadDocuments(partition, batchEntity,connection);
			}

			message = "Uploaded the file successfully: " + file.getOriginalFilename();
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
		} catch (Exception e) {
			message = "Could not upload the file: " + file.getOriginalFilename() + "!";
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
		}
	}
	
	@PostMapping("/split-input-file")
	  public ResponseEntity<ResponseMessage> splitFile(
			  @RequestParam("file") MultipartFile file)
	{
		try {
			List<String> listOfPolicies = FileUtil.readByJava8(file);
			for (List<String> partition : Lists.partition(listOfPolicies, Integer.parseInt(threadCount))) {
//				System.out.println(partition);
				cmDocumentDownloadService.splitFile(partition);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage("Done!"));
	}
	@PostMapping("/getFileSize")
	public ResponseEntity<ResponseMessage> getFileSize( @RequestParam("folder") String folderPath )
	{
		List<String> str = new ArrayList<String>();
		try {
			str = FileUtil.pullSize(folderPath);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(str.toString()));
	}

}
