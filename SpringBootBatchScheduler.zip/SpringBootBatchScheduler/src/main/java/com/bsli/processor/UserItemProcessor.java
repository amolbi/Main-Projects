package com.bsli.processor;

import org.springframework.batch.item.ItemProcessor;

import com.bsli.model.User;

public class UserItemProcessor implements ItemProcessor<User, User>{

	@Override
	public User process(User person) throws Exception {
		return person;
	}
}
