package com.bsli.batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBatchSchedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}
